using System.Collections.Generic;
using System.Linq;
using RestApiEscola.Domain.Interfaces;
using RestApiEscola.Domain.Models;
namespace RestApiEscola.Persistence.Memory
{
    public class EscolaRepository : IEscolaRepository
    {
        private static int idCount = 1;
        private Dictionary<int, Professor> professores = new Dictionary<int, Professor>();

        public List<Professor> ListAll()
        {
            return professores.Values.ToList();
        }

        public Professor GetById(int id)
        {
            if (professores.ContainsKey(id))
                return professores[id];
            else
                return null;
        }
        public void Add(Professor professor)
        {
            professor.Id = idCount++;
            professores.Add(professor.Id, professor);
        }

        public void Update(Professor professor)
        {
            if (professores.ContainsKey(professor.Id))
                professores[professor.Id] = professor;
        }

        public void DeleteById(int id)
        {
            if (professores.ContainsKey(id))
                professores.Remove(id);
        }
    }
}
    