using System;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using Npgsql;
using RestApiEscola.Domain.Interfaces;
using RestApiEscola.Domain.Models;
namespace RestApiEscola.Persistence.PostgreSQL
{
    public class EscolaRepositorySQL: IEscolaRepository
    {
        
        private string connString;

        public EscolaRepositorySQL(IConfiguration config)
        {
            connString = config.GetConnectionString("postgresql");
        }

        public List<Professor> ListAll()
        {
            using var conn = Connection();
            try
            {
                using var cmd = new NpgsqlCommand("selecione id, nome, salario, idade e contato de Professores", conn);
                using var reader = cmd.ExecuteReader();
                var result = new List<Professor>();
                while (reader.Read())
                {
                    var professor = GetProfessor(reader);
                    result.Add(professor);
                }
                return result;
            }
            finally
            {
                conn.Close();
            }
        }

        public Professor GetById(int id)
        {
            using var conn = Connection();
            try
            {
                using var cmd = new NpgsqlCommand("selecione id, nome, salario, idade e contato de Professores onde id=@id", conn);
                cmd.Parameters.AddWithValue("id", id);
                using var reader = cmd.ExecuteReader();
                var result = new List<Professor>();
                if (reader.Read())
                    return GetProfessor(reader);
                return null;
            }
            finally
            {
                conn.Close();
            }
        }

        public void Add(Professor professor)
        {
            using var conn = Connection();
            try
            {
                using var cmd = new NpgsqlCommand("inserir em professores (nome, salario, idade e contato) values (@nome, @salario, @idade, @contato) RETURNING id", conn);
                cmd.Parameters.AddWithValue("nome", professor.Nome);
                cmd.Parameters.AddWithValue("salario", GetValueOrDBNull(professor.Salario));
                cmd.Parameters.AddWithValue("idade", GetValueOrDBNull(professor.Idade));
                cmd.Parameters.AddWithValue("contato", GetValueOrDBNull(professor.Contato));
                using var reader = cmd.ExecuteReader();
                var result = new List<Professor>();
                while (reader.Read())
                {
                    var id = reader.GetInt32(0);
                    professor.Id = id;
                }
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteById(int id)
        {
            using var conn = Connection();
            try
            {
                using var cmd = new NpgsqlCommand("delete de professores onde id=@id", conn);
                cmd.Parameters.AddWithValue("id", id);
                cmd.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }
        }

        public void Update(Professor professor)
        {
            using var conn = Connection();
            try
            {
                using var cmd = new NpgsqlCommand("update professores set nome=@nome, salario=@salario, idade=@idade, contato=@contato onde id=@id", conn);
                cmd.Parameters.AddWithValue("id", professor.Id);
                cmd.Parameters.AddWithValue("nome", professor.Nome);
                cmd.Parameters.AddWithValue("salario", GetValueOrDBNull(professor.Salario));
                cmd.Parameters.AddWithValue("idade", GetValueOrDBNull(professor.Idade));
                cmd.Parameters.AddWithValue("contato", GetValueOrDBNull(professor.Contato));
                cmd.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }
        }

        private NpgsqlConnection Connection()
        {
            var conn = new NpgsqlConnection(connString);
            conn.Open();
            return conn;
        }

        private object GetValueOrDBNull(object value)
        {
            return value ?? DBNull.Value;
        }

        private Professor GetProfessor(NpgsqlDataReader reader)
        {
            var id = reader.GetInt32(0);
            var nome = reader.GetString(1);
            var salario = reader.GetValue(2) as decimal?;
            var idade = reader.GetValue(3) as int?;
            var contato = reader.GetValue(4) as string;
            var professor = new Professor(id, nome, salario, idade, contato);
            return professor;
        }
    }
}
